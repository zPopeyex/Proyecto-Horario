
package Mundo;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Horario {
    
    public Horario(){
        
        
    }
    
    public void leerMateria(){
       
        try {
            
            BufferedReader br = new BufferedReader(new FileReader("./data/materias.txt"));
            int numMaterias = Integer.parseInt(br.readLine());
            System.out.println("NUM MATERIAS: "+numMaterias);
            //Atributos Materia
            for (int i = 0; i < numMaterias; i++) {
            String Nombre = br.readLine();
            System.out.println("eL NOMBRE DE LA MATERIA ES: "+Nombre);
            int Codigo = Integer.parseInt(br.readLine());
            System.out.println("CODIGO: "+Codigo);
            int Salon = Integer.parseInt(br.readLine());
            
            //Atributos docente
            String elNombre = br.readLine();
            int Id = Integer.parseInt(br.readLine());
            String  Especializacion = br.readLine();
            String Genero = br.readLine();
            
            
            //Toma el tamaño de la matriz
            System.out.println("eL NOMBRE DE LA MATERIA ES: "+Nombre);
            }
            
            br.close();
            
            
        }
        catch (FileNotFoundException e) {
            System.out.println("eRROR" + e);
        }
        catch (IOException e){
            System.out.println("eRROR" + e);
        }
        
    }   
        
        
        
}
    
    
            
            
 
 /*try {
            File f = new File(".\\src\\data\\pruebita.txt");
            BufferedReader b = new BufferedReader (new FileReader(f));
            StringTokenizer s = new StringTokenizer(b.readLine(),",");
            
            
        } catch (Exception e) {
        }
        
        */